#include "uni_klee_runtime.h"

// UNI_KLEE_START
int __cpr_choice(char* lid, char* typestr,
                     int* rvals, char** rvals_ids, int rvals_size,
                     int** lvals, char** lvals_ids, int lvals_size){
  int result;
  int x = rvals[0];
  int y = rvals[1];
  int constant_a = 4;
  result = (constant_a < x);
  return result;
}
// UNI_KLEE_END

int __cpr_output(char* id, char* typestr, int value){
  return value;
}
